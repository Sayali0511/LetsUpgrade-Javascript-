var arr = [];

 for(var i=1; i<=5;i++){
     arr[i] = Number(prompt("Enter a positive number" ,"Enter here"));
 }

 console.log(arr);

 let odd = arr.filter(n1=>n1%2==1);
 console.log(odd);

 let cube = arr.filter(n1=>n1%2==1).map(n1=>Math.pow(n1,3));
 console.log(cube);

 

    
    
    




