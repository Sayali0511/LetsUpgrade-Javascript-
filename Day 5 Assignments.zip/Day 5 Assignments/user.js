class User{
    constructor(name, age,email) {
        this.name = name;
        this.age = age;
        this.email = email;
        this.Coins = 0;
        this.courses = [];
      }

      login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
   

}

class Moderator extends User{

constructor(name,age,email,Coins){
    super(name,age,email)
    this.Coins = Coins;
}
    addCoins(val){
        this.Coins = val;
        console.log(`${this.name} has ${this.Coins} coins`);
        return this;
    }

    removeCoins(val){
        this.Coins -= val;
        console.log(`${this.name} has ${this.Coins} coins`);
        return this;
    }
}

class Admin extends Moderator{
    constructor(name,age,email,Coins,course){
        super(name,age,email,Coins)
        this.courses = course
    }
    addCourse(user,course){
        user.courses.push(course);
        console.log(user);
    }
    
}

let user1 = new User('Sahil', 23, 'S@gmail.com');

let user2 = new User('Dravid', 27, 'Da@gmail.com');

let mod = new Moderator('Tushar', 33,'T@gmail.com');

let adm = new Admin('Rahul', 30, 'raa@gmail.com');

let users = [user1,user2,mod,adm];

users.forEach(el => {
    console.log(el);
});

adm.addCourse(user1,'Javascript');
adm.addCourse(user1,'Python');

user1.login();
user2.login();
user1.logout();

adm.login().addCoins(2).logout;
mod.login().addCoins(5).removeCoins(1).logout();


