var marks = Number(prompt("Please enter marks", "<marks>"));

if(marks>50){
    console.log("Marks are " +marks + " and grade is A ") ;
}else{
        console.log("Marks are " +marks + " and grade is B ") ;

}