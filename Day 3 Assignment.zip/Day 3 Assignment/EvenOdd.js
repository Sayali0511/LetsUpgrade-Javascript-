let number = Number(prompt("Please enter any number", "<number goes here>"));

if (number % 2 == 0) {

   console.log("Entered number "+number + " is Even");

}else{
    console.log("Entered number "+number+ " is Odd");
}
