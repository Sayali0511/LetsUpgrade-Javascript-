 var str1 = prompt("Please enter OS name and version ", "<OS name version >"); 

 var array = str1.split(" ");

console.log("OS name " + array[0]+ " and version " + array[1] );