let student = {
         name:'Helsinki',
         age:24,
        Projects : {
           DiceGame:'Two players dice game using JavaScript'
         },
     }


//const {age, name} = student;
//console.log(age,name);

const {name, Projects:{DiceGame}} = student;
console.log(name, DiceGame);