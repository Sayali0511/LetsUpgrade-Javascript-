
var sales = Number(prompt("Sales made during the year","Enter here"))

if(sales>= 0 && sales<=5000){
    console.log("The total commission earned is 2%");

}else if(sales>= 5001 && sales<=10000 ){
    console.log("The total commission earned is 5%");

}else if(sales>= 10001 && sales<=20000){
    console.log("The total commission earned is 7%");

}else{
    console.log("The total commission earned is 10%");

}
