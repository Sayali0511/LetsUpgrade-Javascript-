let n = Number(prompt("Enter the value for n","Enter here"))

ToPrime:
    for(let i = 2; i <= n; i++){
        for(j=2; j<i; j++){
            if(i % j == 0) {
                continue ToPrime
            } 
            document.write("")
        }
        document.write(i)
    }

