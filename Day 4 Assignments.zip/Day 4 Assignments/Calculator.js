
function display(val){
    document.getElementById('display1').value += val
}

function solve() {
    let x = document.getElementById('display1').value
    let y = eval(x)
    document.getElementById('display1').value = y
}

function clr(){
    document.getElementById("display1").value=''
   
}

function sqrt1(){
    var num = document.getElementById('display1').value 
    var result = Math.sqrt(num)
    document.getElementById("display1").value = result
}