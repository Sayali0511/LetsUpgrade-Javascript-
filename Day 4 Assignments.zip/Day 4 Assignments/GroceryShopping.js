let shoppingList = ['Wheat','Sugar','Rice','Tea Powder','Salt','Groundnuts'];
let shoppingBasket = [...shoppingList,'Coffee Powder','Tur Dal','Soaps'];

//console.log(shoppingList);
console.log(shoppingBasket);
