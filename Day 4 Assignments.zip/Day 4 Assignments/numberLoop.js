
do{
    var number = Number(prompt("Enter a number greater than 100","Enter Here"))

}while(number < 100 || number == '')



