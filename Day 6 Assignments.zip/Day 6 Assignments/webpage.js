//Welcome Message
const name = prompt("Enter your name","Enter name here");

Name.innerText += `Welcome to the family ${name}`;

//Clock
const ctime = document.getElementById('time');

function clock(){
    let date = new Date();
    let time = date.toLocaleTimeString();
    ctime.innerText = time;
}
setInterval(clock,1000);

//Dark Mode
const dmode = document.getElementById('dark');
dmode.onclick = function changeColor(){
    
    document.body.style.backgroundColor = 'black';
    document.body.style.color = 'white';   
}