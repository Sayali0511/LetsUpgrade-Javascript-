var btn = document.getElementById('btn');

btn.onclick = function NumTable(){
    var space = document.getElementById('table');
    var number  = document.getElementById('num1').value;
    
     for(let i=1; i<=10; i++){
     
        mul = `${number} * ${i}` ;
        result = eval(`${number} *${i}` );
        space.innerHTML +=  `<br> ${mul} = ${result}`;   
      
    }
      
}
    

    
