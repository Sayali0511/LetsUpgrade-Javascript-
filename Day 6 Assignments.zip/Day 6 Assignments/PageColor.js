function changeBodyBg(color){
    document.body.style.background = color;
}

let colors = ['Red','Yellow','Wheat'];

for(let i= 0; i<colors.length; i++){
let col = colors[i];
setInterval(changeBodyBg(col),3000);

} 