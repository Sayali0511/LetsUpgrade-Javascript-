let name = "Sonali";
let college_name = "ACFGH";
let city = "Solapur";

console.log("The name is " + name + " .His college name is " + college_name + " and his native place is " + city);
